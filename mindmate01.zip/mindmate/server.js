const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const { q, init, seedRoutines } = require('./database');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
const wrap = fn => (req, res) => fn(req, res).catch(e => { console.error(e); res.status(500).json({ error: 'Server error' }); });

const hashPin = pin => { const s = crypto.randomBytes(8).toString('hex'); return s + ':' + crypto.scryptSync(pin, s, 32).toString('hex'); };
const checkPin = (pin, h) => { const [s, k] = h.split(':'); const a = crypto.scryptSync(String(pin), s, 32); return crypto.timingSafeEqual(a, Buffer.from(k, 'hex')); };
const fails = {}; // patient -> {n, until}: 5 wrong passcodes = 60 s lockout

async function patient(req, res, next) {
  const id = req.get('x-patient');
  const [p] = id ? await q('SELECT * FROM patients WHERE id=$1', [id]) : [];
  if (!p) return res.status(404).json({ error: 'Unknown patient. Set up the app again.' });
  req.p = p; next();
}
const guard = fn => [wrap(async (req, res, next) => patient(req, res, next)), wrap(fn)];

app.post('/api/patients', wrap(async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 60), pin = String(req.body.pin || '');
  if (!name || !/^\d{4,8}$/.test(pin)) return res.status(400).json({ error: 'Enter a name and a 4 to 8 digit passcode.' });
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const id = Array.from(crypto.randomBytes(6), b => A[b % A.length]).join('');
  await q('INSERT INTO patients (id, name, pin_hash) VALUES ($1,$2,$3)', [id, name, hashPin(pin)]);
  await seedRoutines(id);
  res.status(201).json({ id, name });
}));

app.get('/api/patients/:id', wrap(async (req, res) => {
  const [p] = await q('SELECT id, name FROM patients WHERE id=$1', [req.params.id.toUpperCase()]);
  p ? res.json(p) : res.status(404).json({ error: 'Code not found.' });
}));

app.get('/api/routines', ...guard(async (req, res) =>
  res.json(await q('SELECT * FROM routines WHERE patient_id=$1 ORDER BY scheduled_time', [req.p.id]))));

app.post('/api/routines/:id/toggle', ...guard(async (req, res) => {
  await q('UPDATE routines SET is_completed = 1 - is_completed, updated_at = CURRENT_TIMESTAMP WHERE id=$1 AND patient_id=$2', [req.params.id, req.p.id]);
  const [r] = await q('SELECT * FROM routines WHERE id=$1 AND patient_id=$2', [req.params.id, req.p.id]);
  r ? res.json(r) : res.status(404).json({ error: 'Not found' });
}));

// Composite = 0.5*(Acc/100) - 0.3*(Lat/2000) - 0.2*(Err/5); levels 1..4 (2x2, 3x2, 4x3, 4x4)
app.post('/api/telemetry/game', ...guard(async (req, res) => {
  const { game_type = 'memory_match', level = 1, accuracy, reaction_latency_ms, errors = 0 } = req.body;
  if ([accuracy, reaction_latency_ms, level, errors].some(v => typeof v !== 'number' || !isFinite(v)))
    return res.status(400).json({ error: 'accuracy, reaction_latency_ms, level, errors must be numbers' });
  const score = 0.5 * (accuracy / 100) - 0.3 * (reaction_latency_ms / 2000) - 0.2 * (errors / 5);
  let next = level, action = 'keep';
  if (score >= 0.3) { next = Math.min(4, level + 1); if (next > level) action = 'increase'; }
  else if (score < 0) { next = Math.max(1, level - 1); if (next < level) action = 'decrease'; }
  await q('INSERT INTO game_telemetry (patient_id, game_type, level, accuracy, reaction_latency_ms, dda_score) VALUES ($1,$2,$3,$4,$5,$6)',
    [req.p.id, String(game_type).slice(0, 30), level, accuracy, reaction_latency_ms, score]);
  res.json({ dda_score: +score.toFixed(3), action, next_level: next });
}));

// CHI (0-100) = 50% accuracy + 30% speed (0 ms = 100, 3000 ms+ = 0) + 20% routine compliance
app.get('/api/caregiver/stats', ...guard(async (req, res) => {
  const f = fails[req.p.id] || { n: 0, until: 0 };
  if (Date.now() < f.until) return res.status(429).json({ error: 'Too many tries. Wait a minute.' });
  if (!checkPin(req.get('x-pin') || '', req.p.pin_hash)) {
    f.n++; if (f.n >= 5) { f.n = 0; f.until = Date.now() + 60000; } fails[req.p.id] = f;
    return res.status(401).json({ error: 'Wrong passcode' });
  }
  delete fails[req.p.id];
  const [g] = await q('SELECT AVG(accuracy) acc, AVG(reaction_latency_ms) lat, COUNT(*) n FROM (SELECT * FROM game_telemetry WHERE patient_id=$1 ORDER BY id DESC LIMIT 20) t', [req.p.id]);
  const [rt] = await q('SELECT COUNT(*) total, SUM(is_completed) done FROM routines WHERE patient_id=$1', [req.p.id]);
  const n = Number(g.n), total = Number(rt.total), comp = total ? 100 * Number(rt.done || 0) / total : 0;
  const acc = Number(g.acc || 0), lat = Number(g.lat || 0);
  const speed = n ? Math.max(0, 100 - lat / 30) : 0;
  const recent = (await q('SELECT level, accuracy, reaction_latency_ms, timestamp FROM game_telemetry WHERE patient_id=$1 ORDER BY id DESC LIMIT 7', [req.p.id])).reverse();
  res.json({ code: req.p.id, name: req.p.name, chi: n ? Math.round(0.5 * acc + 0.3 * speed + 0.2 * comp) : 0,
    touch_latency_s: +(lat / 1000).toFixed(2), compliance: Math.round(comp), sessions: n, recent });
}));

init().then(() => app.listen(process.env.PORT || 3000, () => console.log('Mind-Mate AI running')))
  .catch(e => { console.error('DB init failed', e); process.exit(1); });

# Mind-Mate AI (SIH26003)

## Run locally
```bash
npm install
npm start      # http://localhost:3000
```
Env vars: `PORT`, `DATABASE_URL` (SQLite path like `/data/mindmate.db`, or `postgres://...` for PostgreSQL; `PGSSL=false` for local Postgres), `NODE_ENV`.
First launch shows a setup screen: create a patient with a caregiver passcode, or connect another phone with the 6-letter patient code (shown in the caregiver dashboard).

## Build the Android APK (Capacitor)
Requires Node 18+, JDK 17, Android Studio (SDK installed).
1. Set your deployed API in `public/index.html` before `const API`: `<script>window.MM_API='https://YOUR-APP.onrender.com'</script>`
2. `npm install && npx cap add android && npx cap sync android`
3. `cd android && ./gradlew assembleDebug`
4. APK: `android/app/build/outputs/apk/debug/app-debug.apk` (or `npx cap open android` to run from Android Studio).
5. Add `android:usesCleartextTraffic="true"` only for local http testing; use https in production.

## Deploy
**Backend (Render):** New Web Service from your GitHub repo. Build `npm install`, start `npm start`. Add a Disk mounted at `/data` and set `DATABASE_URL=/data/mindmate.db`, `NODE_ENV=production`, . Render sets `PORT`. (Railway: same, attach a volume.)
The Express server also serves `public/`, so one service hosts both app and API.

**Split frontend (Vercel/Netlify):** publish `public/`, and set `window.MM_API` to the backend URL, or add a rewrite `/api/* -> https://YOUR-APP.onrender.com/api/*`.

**PostgreSQL:** set `DATABASE_URL=postgres://...` and tables are created automatically (same code, no changes). `render.yaml` provisions the web service and a Postgres database together (Render Blueprint). Set `PGSSL=off` for a local Postgres.

**Vercel/Netlify:** `vercel.json` proxies `/api/*` to the backend; edit the destination URL.

## Translations
Assamese, Bengali, Manipuri, Khasi and Mizo strings are drafts in `public/i18n.js` flagged `reviewed:false`; the app shows a notice for unreviewed languages. Have native speakers or ASHA workers verify, then set `reviewed:true`.

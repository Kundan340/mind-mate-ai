// One interface, two engines: SQLite file (dev) or PostgreSQL (DATABASE_URL=postgres://...).
const url = process.env.DATABASE_URL || './mindmate.db';
const isPg = /^postgres(ql)?:\/\//.test(url);
let pool, sq;
if (isPg) {
  const { Pool } = require('pg');
  pool = new Pool({ connectionString: url, ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized: false } });
} else {
  sq = new (require('better-sqlite3'))(url);
  sq.pragma('journal_mode = WAL');
}
// Use $1, $2 ... placeholders in order of appearance.
async function q(sql, params = []) {
  if (isPg) return (await pool.query(sql, params)).rows;
  const st = sq.prepare(sql.replace(/\$\d+/g, '?'));
  return st.reader ? st.all(...params) : (st.run(...params), []);
}
const ID = isPg ? 'SERIAL PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
const SEED = [
  ['Drink a glass of water', 'hydration', '07:00'], ['Morning medicine', 'medicine', '08:00'],
  ['Drink a glass of water', 'hydration', '11:00'], ['Memory game', 'cognitive', '11:30'],
  ['Afternoon water', 'hydration', '15:00'], ['Evening medicine', 'medicine', '20:00'],
];
async function seedRoutines(pid) {
  for (const [t, c, s] of SEED)
    await q('INSERT INTO routines (patient_id, title, category, scheduled_time) VALUES ($1,$2,$3,$4)', [pid, t, c, s]);
}
async function init() {
  await q(`CREATE TABLE IF NOT EXISTS patients (id TEXT PRIMARY KEY, name TEXT NOT NULL, pin_hash TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await q(`CREATE TABLE IF NOT EXISTS game_telemetry (id ${ID}, patient_id TEXT NOT NULL, game_type TEXT NOT NULL, level INTEGER NOT NULL, accuracy REAL NOT NULL, reaction_latency_ms REAL NOT NULL, dda_score REAL NOT NULL, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await q(`CREATE TABLE IF NOT EXISTS routines (id ${ID}, patient_id TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, scheduled_time TEXT NOT NULL, is_completed INTEGER NOT NULL DEFAULT 0, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
}
module.exports = { q, init, seedRoutines, isPg };

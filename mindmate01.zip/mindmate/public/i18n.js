// Translations. REVIEW every non-English entry with a native speaker or ASHA worker before real patient use.
// Missing keys fall back to English. To add Khasi (kha) or Manipuri (mni), copy the `en` block and translate.
window.T = {
  en:{play:'Play Memory Game',meds:'Medicines & Water',album:'Family Photo Album',talk:'Talk to Companion',home:'Home',call:'Call Caregiver Now',morning:'Morning',afternoon:'Afternoon',evening:'Evening',hello:'Hello! I am here with you. Have you had some water today?',win:'Well done!',tryagain:'Try again'},
  as:{reviewed:false,play:'স্মৃতি খেল খেলক',meds:'দৰব আৰু পানী',album:'পৰিয়ালৰ এলবাম',talk:'লগৰীয়াৰ সৈতে কথা',home:'ঘৰ',call:'এতিয়াই কল কৰক',morning:'পুৱা',afternoon:'দুপৰীয়া',evening:'সন্ধিয়া',hello:'নমস্কাৰ! মই আপোনাৰ লগত আছো। আজি পানী খালেনে?',win:'বহুত ভাল!',tryagain:'আকৌ চেষ্টা কৰক'},
  bn:{reviewed:false,play:'স্মৃতির খেলা খেলুন',meds:'ওষুধ ও জল',album:'পারিবারিক অ্যালবাম',talk:'সঙ্গীর সাথে কথা',home:'হোম',call:'এখনই কল করুন',morning:'সকাল',afternoon:'দুপুর',evening:'সন্ধ্যা',hello:'নমস্কার! আমি আপনার সঙ্গে আছি। আজ জল খেয়েছেন?',win:'খুব ভালো!',tryagain:'আবার চেষ্টা করুন'},
  lus:{reviewed:false,play:'Hriatna Khel Khelin',meds:'Damdawi leh Tui',album:'Chhungkua Thlalak',talk:'Ka Nena Thu Sawi',home:'In',call:'Enkawltu Ko Nghal Rawh',morning:'Zing',afternoon:'Chawhnu',evening:'Zan',hello:'Chibai! Ka la awm che a. Vawiin hian tui i in tawh em?',win:'A tha hle!',tryagain:'Threuh nawn rawh'},
  kha:{reviewed:false,play:'Pyrta ia ka Jingmyntoi',meds:'Dawai bad Um',album:'Ki Photo jong ka Kur',talk:'Kren bad Iaka',home:'Ïing',call:'Khot Mynta',win:'Khublei! Ka bha!',tryagain:'Pyrta shuh'}, // TODO: Khasi translation needed
  mni:{reviewed:false,play:'Yaadaba Game Tounabra',meds:'Wai amasung Ising',album:'Yumgi Photo',talk:'Companion da Khonjel',home:'Yum',call:'Caregiver Khongba',win:'Khudaiyal, Yamna Phajei!',tryagain:'Chatna Toubro'} // TODO: Manipuri translation needed
};
